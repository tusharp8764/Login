﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ePES.Entity;
using ePES.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ePES.DAL;

namespace ePES.BL
{
    public class PolicyValidations
    {
        PolicyOperations poloperations;

        public DataTable GetPolicy_BLL(int custID, DateTime DOB, int PN, string Name)  // for search
        {
            DataTable dtCust;
            try
            {
                poloperations = new PolicyOperations();

                dtCust = poloperations.GetPolicy_DAL(custID, DOB, PN, Name);

            }
            catch (SqlException)
            {

                throw;
            }
            catch (PolicyExceptions)
            {
                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {


            }
            return dtCust;

        }
    }
}
