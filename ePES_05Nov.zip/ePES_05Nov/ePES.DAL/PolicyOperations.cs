﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ePES.Entity;
using ePES.Exceptions;

namespace ePES.DAL
{
    public class PolicyOperations
    {
        static string plcConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection plcConnObj;
        //  SqlCommand plcCommand;
        //    DataTable dtDept;
        //    SqlDataReader plcReader;
        //   static string ConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        //   static SqlConnection plcConnObj;
        static SqlCommand plcCommand;
        static DataTable dtCust = null;
        static SqlDataReader plcReader;

        public PolicyOperations()
        {
            plcConnObj = new SqlConnection();
            plcConnObj.ConnectionString = plcConnStr;
        }

        //Login User--according to type fetched
        public bool ValidateUser(LoginCredentials log)
        {
            bool isValid = false;
            try
            {
                plcCommand = new SqlCommand("Group2.usp_Login", plcConnObj);
                plcCommand.CommandType = CommandType.StoredProcedure;
                plcCommand.Parameters.AddWithValue("@loginID", log.loginID);
                plcCommand.Parameters.AddWithValue("@userpassword", log.userpassword);
                plcCommand.Parameters.AddWithValue("@userType", log.userType);
                plcConnObj.Open();
                plcReader = plcCommand.ExecuteReader();
                if (plcReader.HasRows)
                {
                    isValid = true;
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (PolicyExceptions)
            {
                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                plcReader.Close();
                if (plcConnObj.State == ConnectionState.Open) plcConnObj.Close();
            }
            return isValid;
        }

        public static int InsertEndorsementTemp_DAL(Endorsements edt)
        {
            int rowsAffected = 0;

            try
            {

                plcCommand = new SqlCommand("Group2.usp_InsertEndoTemp", plcConnObj);

                plcCommand.CommandType = CommandType.StoredProcedure;
                plcCommand.Parameters.AddWithValue("@ccustomerID", edt.customerID);

                plcCommand.Parameters.AddWithValue("@cpolicyNumber", edt.policyNumber);
                plcCommand.Parameters.AddWithValue("@cpolicyName", edt.policyName);
                plcCommand.Parameters.AddWithValue("@cproductLine", edt.productLine);
                plcCommand.Parameters.AddWithValue("@cName", edt.customerName);
                plcCommand.Parameters.AddWithValue("@cAddress", edt.customerAddress);
                plcCommand.Parameters.AddWithValue("@cPh", edt.customerTelephone);
                plcCommand.Parameters.AddWithValue("@cGender", edt.customerGender);
                plcCommand.Parameters.AddWithValue("@cDOB", edt.customerDOB);
                plcCommand.Parameters.AddWithValue("@cSmoking", edt.customerSmoking);

                plcCommand.Parameters.AddWithValue("@cnomineeName", edt.nomineeName);
                plcCommand.Parameters.AddWithValue("@cnomineeRelation", edt.nomineeRelation);

                plcCommand.Parameters.AddWithValue("@cpremiumFrequency", edt.premiumFrequency);
                plcCommand.Parameters.AddWithValue("@cstatusEndo", edt.statusEndo);


                plcConnObj.Open();
                rowsAffected = plcCommand.ExecuteNonQuery();

            }

            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (plcConnObj.State == ConnectionState.Open) plcConnObj.Close();
            }
            return rowsAffected;
        }
        // ---------------------------------------------------------------------------------------
        //LOAD UPDATE FORM

        public DataTable GetEndoPermanent_DAL(int cid, int pn)
        {
            DataTable dtEndo = new DataTable();
            try
            {

                plcCommand = new SqlCommand("Group2.usp_Endorsements", plcConnObj);
                plcCommand.CommandType = CommandType.StoredProcedure;
                plcCommand.Parameters.AddWithValue("@cid", cid);
                plcCommand.Parameters.AddWithValue("@pno", pn);
                plcConnObj.Open();
                plcReader = plcCommand.ExecuteReader();
                if (plcReader.HasRows)
                {
                    dtEndo.Load(plcReader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                plcReader.Close();
                if (plcConnObj.State == ConnectionState.Open) plcConnObj.Close();
            }
            return dtEndo;
        }

        //----------------------------------------------------------------------------

        //search by customer--viewing policy details
        public static DataTable GetPolicy_DAL(int custID, DateTime DOB, int PN, string Name) //search
        {
            try
            {
                dtCust = new DataTable(/*int custID*/);
                plcCommand = new SqlCommand("Group2.usp_SearchPolicy", plcConnObj);
                plcCommand.CommandType = CommandType.StoredProcedure;

                plcCommand.Parameters.AddWithValue("@PN", PN);
                plcCommand.Parameters.AddWithValue("@CID", custID);
                plcCommand.Parameters.AddWithValue("@CName", Name); // cust name
                plcCommand.Parameters.AddWithValue("@DOB", DOB); // dob

                plcConnObj.Open();

                plcReader = plcCommand.ExecuteReader();
                if (plcReader.HasRows)
                {
                    dtCust.Load(plcReader);
                }
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                plcReader.Close();
                if (plcConnObj.State == ConnectionState.Open) plcConnObj.Close();
            }
            return dtCust;
        }



        public static int InsertImageCustDOC_DAL(ImageEntity ie)
        {
            plcCommand = new SqlCommand("Group2.usp_ImageInsert", plcConnObj);
            plcCommand.CommandType = CommandType.StoredProcedure;

            plcCommand.Parameters.AddWithValue("@policyNumber", ie.policyNumber);
            plcCommand.Parameters.AddWithValue("@customerID", ie.customerID);
            plcCommand.Parameters.AddWithValue("@img", ie.picture);

            plcConnObj.Open();
            int rows = plcCommand.ExecuteNonQuery();

            if (plcConnObj.State == ConnectionState.Open) plcConnObj.Close();

            return rows;
        }
    }
}
