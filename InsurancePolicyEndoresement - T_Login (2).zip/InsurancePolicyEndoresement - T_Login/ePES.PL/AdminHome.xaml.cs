﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;
using ePES.BL;
using ePES.Entity;

namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for AdminHome.xaml
    /// </summary>
    public partial class AdminHome : Window
    {
        public AdminHome()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            
  System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.txtUpload.Text = ofd.FileName;
            }


        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            PolicyValidations bl = new PolicyValidations();
            try
            {
                int tID = Convert.ToInt16();
                Image. = bl.ViewImageDAL(id);
                BitmapImage myBitmapImage = new BitmapImage();
                MemoryStream ms = new MemoryStream(im.Image);
                myBitmapImage.BeginInit();
                myBitmapImage.StreamSource = ms;
                myBitmapImage.DecodePixelWidth = 200;
                myBitmapImage.EndInit();
                ImageSource imageSource = myBitmapImage;
                UploadImage.Source = imageSource;
            }
        }
    }
}
