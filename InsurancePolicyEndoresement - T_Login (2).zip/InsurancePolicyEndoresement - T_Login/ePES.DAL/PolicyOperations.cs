﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ePES.Entity;
using ePES.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ePES.DAL
{
    public class PolicyOperations
    {
        static string ConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection ConnObj;
        SqlCommand Command;
        DataTable dtCust = null;
        SqlDataReader Reader = null;

        public PolicyOperations()
        {
            ConnObj = new SqlConnection();
            ConnObj.ConnectionString = ConnStr;
        }

        //search by customer--viewing policy details
        public DataTable GetPolicy_DAL(int custID, DateTime DOB, int PN, string Name) //search
        {
            try
            {
                dtCust = new DataTable(/*int custID*/);
                Command = new SqlCommand("Group2.usp_SearchPolicy", ConnObj);
                Command.CommandType = CommandType.StoredProcedure;
                Command.Parameters.AddWithValue("@CID", custID);  // policy number
                Command.Parameters.AddWithValue("@DOB", DOB); // dob
                Command.Parameters.AddWithValue("@PN", PN); // cust id    OR
                Command.Parameters.AddWithValue("@CName", Name); // cust name
                ConnObj.Open();
                Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    dtCust.Load(Reader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (PolicyExceptions)
            {
                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                Reader.Close();
                if (ConnObj.State == ConnectionState.Open) ConnObj.Close();
            }
            return dtCust;
        }


        public void ImageInsertDAL(ImageEntity newImage)
        {
            try
            {
                byte[] imageData = (.Text);    //This nethod returns image in byte array format.
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=aaaa;User ID=sa;Password=abcd;Initial Catalog=Workbook";  //provide connection string of your server.
                con.Open();   //open connection to server.
                string query = "insert into ImageTable values(@imageId,@imageData)";     //create a query variable.
                SqlCommand cmd = new SqlCommand(query, con);          //create a sqlcommand object.
                cmd.Parameters.Add(new SqlParameter("@customerID",));    //add first parameters.
                cmd.Parameters.Add(new SqlParameter("@imageData", imageData));    //add second parameters.
                int rows = cmd.ExecuteNonQuery();         //execute query.
                if (rows > 0)
                    .Show("Image saved.");
                else
                    MessageBox.Show("Unable to save image.");
                con.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

            
            

